
using PyPlot

function plotRunNaive(iname, zinit, zls, zbest)
    figure("Examen d'un run",figsize=(6,6)) # Create a new figure
    title("Naive-SPP | \$z_{Init}\$  \$z_{LS}\$  \$z_{Best}\$ | " * iname)
    xlabel("Itérations")
    ylabel("valeurs de z(x)")
    ylim(0, maximum(zbest)+2)

    nPoint = length(zinit)
    x=collect(1:nPoint)
    xticks([1,convert(Int64,ceil(nPoint/4)),convert(Int64,ceil(nPoint/2)), convert(Int64,ceil(nPoint/4*3)),nPoint])
    plot(x,zbest, linewidth=2.0, color="green", label="meilleures solutions")
    plot(x,zls,ls="",marker="^",ms=2,color="green",label="toutes solutions améliorées")
    plot(x,zinit,ls="",marker=".",ms=2,color="red",label="toutes solutions construites")
    vlines(x, zinit, zls, linewidth=0.5)
    legend(loc=4, fontsize ="small")
end

function plotAnalyseNaive(iname, x, zmoy, zmin, zmax)
    figure("bilan tous runs",figsize=(6,6)) # Create a new figure
    title("Naive-SPP | \$z_{min}\$  \$z_{moy}\$  \$z_{max}\$ | " * iname)
    xlabel("Itérations (pour nbRunGrasp)")
    ylabel("valeurs de z(x)")
    ylim(0, zmax[end]+2)

    nPoint = length(x)
    intervalle = [reshape(zmoy,(1,nPoint)) - reshape(zmin,(1,nPoint)) ; reshape(zmax,(1, nPoint))-reshape(zmoy,(1,nPoint))]
    xticks(x)
    errorbar(x,zmoy,intervalle,lw=1, color="black", label="zMin zMax")
    plot(x,zmoy,linestyle="-", marker="o", ms=4, color="green", label="zMoy")
    legend(loc=4, fontsize ="small")
end

function plotCPUt(allfinstance, tmoy)
    figure("bilan CPUt tous runs",figsize=(6,6)) # Create a new figure
    title("Naive-SPP | tMoy")
    ylabel("CPUt moyen (s)")

    xticks(collect(1:length(allfinstance)), allfinstance, rotation=60, ha="right")
    margins(0.15)
    subplots_adjust(bottom=0.15,left=0.21)
    plot(collect(1:length(allfinstance)),tmoy,linestyle="--", lw=0.5, marker="o", ms=4, color="blue", label="tMoy")
    legend(loc=4, fontsize ="small")
end


function eval(dir, nbRuns)
    files = getfname(dir)
    C, A = loadSPP(string("./Data/didactic.dat"))
    s = sum(A, dims=1)
    C = reshape(C,  1, length(C))
    v = C ./ s
    sorted = sortperm(v, dims = 2, rev=true)
    x0, res = optimiz(C, A)
    x0, res = optimiz(C, A)
    time_runs = zeros(length(files))
    xbest = zeros(length(files))
    x0 = zeros(length(files))
    for i in 1:length(files)
        C, A = loadSPP(string(dir,files[i]))
        s = sum(A, dims=1)
        C = reshape(C,  1, length(C))
        v = C ./ s
        sorted = sortperm(v, dims = 2, rev=true)
        temp_time = 0
        for j in 1:nbRuns
            start = time()
            x0, xbest, res = optimiz(C, A)
            println("x0 : ",x0, ", xbest: ",xbest)
            temp_time += (time() - start)
            if(j==1)
                #plotRunNaive(files[i], x0, xbest, xbest)
        end
        #plotAnalyseNaive(files[i], x0, xbest, xbest)
        
        time_runs[i] = temp_time / nbRuns
        #println(time_runs[i])
        #W = transpose(res) .* C
    end
    println(time_runs)
    plotCPUt(files, time_runs)
    #plotRunNaive(files, x0, zbest, zbest)


end 

